For examples please check the documentation: https://arnaud-lb.github.io/php-rdkafka/phpdoc/rdkafka.examples.html
